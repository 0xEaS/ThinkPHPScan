package burp;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Tags extends AbstractTableModel implements ITab, IMessageEditorController{

    private IBurpExtenderCallbacks callbacks;
    private IExtensionHelpers helpers;
    private String tagName;
    private JSplitPane mjSplitPane;
    private List<Tags.TablesData> Udatas = new ArrayList();
    private IMessageEditor HRequestTextEditor;
    private IMessageEditor HResponseTextEditor;
    private IHttpRequestResponse currentlyDisplayedItem;
    private Tags.URLTable Utable;
    private JScrollPane UscrollPane;
    private JSplitPane HjSplitPane;
    private JTabbedPane Ltable;
    private JTabbedPane Rtable;

    public Tags(IBurpExtenderCallbacks callbacks, String name) {
        this.callbacks = callbacks;
        this.helpers = callbacks.getHelpers();
        this.tagName = name;
        //创建自定义UI
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Tags.this.mjSplitPane = new JSplitPane(0);//垂直分割
                Tags.this.Utable = Tags.this.new URLTable(Tags.this);
                Tags.this.UscrollPane = new JScrollPane(Tags.this.Utable);
                Tags.this.HjSplitPane = new JSplitPane();//默认水平分割
                Tags.this.HjSplitPane.setDividerLocation(0.5D);
                //request/response视图
                Tags.this.Ltable = new JTabbedPane();
                Tags.this.HRequestTextEditor = Tags.this.callbacks.createMessageEditor(Tags.this, false);
                Tags.this.Ltable.addTab("Request", Tags.this.HRequestTextEditor.getComponent());
                Tags.this.Rtable = new JTabbedPane();
                Tags.this.HResponseTextEditor = Tags.this.callbacks.createMessageEditor(Tags.this, false);
                Tags.this.Rtable.addTab("Response", Tags.this.HResponseTextEditor.getComponent());
                //水平分割，分成两个tab
                Tags.this.HjSplitPane.add(Tags.this.Ltable, "left");
                Tags.this.HjSplitPane.add(Tags.this.Rtable, "right");
                //垂直分割
                Tags.this.mjSplitPane.add(Tags.this.UscrollPane, "left");
                Tags.this.mjSplitPane.add(Tags.this.HjSplitPane, "right");
                //设置自定义组件并添加标签
                Tags.this.callbacks.customizeUiComponent(Tags.this.mjSplitPane);
                //在Burp中添加自定义的插件的Tab界面
                Tags.this.callbacks.addSuiteTab(Tags.this);
            }
        });

    }

    @Override
    public IHttpService getHttpService() {
        return this.currentlyDisplayedItem.getHttpService();
    }

    @Override
    public byte[] getRequest() {
        return this.currentlyDisplayedItem.getRequest();
    }

    @Override
    public byte[] getResponse() {
        return this.currentlyDisplayedItem.getResponse();
    }

    @Override
    public String getTabCaption() {
        //UI标题名
        return this.tagName;
    }

    @Override
    public Component getUiComponent() {
        // Burp 调用此方法获取自定义标签页显示的组件
        return this.mjSplitPane;
    }

    @Override
    public int getRowCount() {
        return this.Udatas.size();
    }

    @Override
    public int getColumnCount() {
        return 6;
    }

    public String getColumnName(int columnIndex) {
        switch(columnIndex) {
            case 0:
                return "#";
            case 1:
                return "url";
            case 2:
                return "statusCode";
            case 3:
                return "issue";
            case 4:
                return "startTime";
            case 5:
                return "endTime";
            default:
                return null;
        }
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Tags.TablesData datas = (Tags.TablesData)this.Udatas.get(rowIndex);
        switch(columnIndex) {
            case 0:
                return datas.id;
            case 1:
                return datas.url;
            case 2:
                return datas.statusCode;
            case 3:
                return datas.issue;
            case 4:
                return datas.startTime;
            case 5:
                return datas.endTime;
            default:
                return null;
        }
    }

    public static class TablesData {
        final int id;
        final String url;
        final String statusCode;
        final String issue;
        final IHttpRequestResponse requestResponse;
        final String startTime;
        final String endTime;

        public TablesData(int id, String url, String statusCode, String issue, IHttpRequestResponse requestResponse, String startTime, String endTime) {
            this.id = id;
            this.url = url;
            this.statusCode = statusCode;
            this.issue = issue;
            this.requestResponse = requestResponse;
            this.startTime = startTime;
            this.endTime = endTime;
        }
    }

    public class URLTable extends JTable {
        public URLTable(TableModel tableModel) {
            super(tableModel);
        }

        public void changeSelection(int row, int col, boolean toggle, boolean extend) {
            Tags.TablesData dataEntry = (Tags.TablesData)Tags.this.Udatas.get(this.convertRowIndexToModel(row));
            Tags.this.HRequestTextEditor.setMessage(dataEntry.requestResponse.getRequest(), true);
            Tags.this.HResponseTextEditor.setMessage(dataEntry.requestResponse.getResponse(), false);
            Tags.this.currentlyDisplayedItem = dataEntry.requestResponse;
            super.changeSelection(row, col, toggle, extend);
        }
    }

    public int add(String url, String statusCode, String issue, IHttpRequestResponse requestResponse) {
        synchronized(this.Udatas) {
            Date d = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String startTime = sdf.format(d);
            int id = this.Udatas.size();
            this.Udatas.add(new Tags.TablesData(id, url, statusCode, issue, requestResponse, startTime, ""));
            this.fireTableRowsInserted(id, id);
            return id;
        }
    }

    public int save(int id, String url, String statusCode, String issue, IHttpRequestResponse requestResponse) {
        Tags.TablesData dataEntry = (Tags.TablesData)this.Udatas.get(id);
        String startTime = dataEntry.startTime;
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String endTime = sdf.format(d);
        synchronized(this.Udatas) {
            this.Udatas.set(id, new Tags.TablesData(id, url, statusCode, issue, requestResponse, startTime, endTime));
            this.fireTableRowsUpdated(id, id);
            return id;
        }
    }
}
