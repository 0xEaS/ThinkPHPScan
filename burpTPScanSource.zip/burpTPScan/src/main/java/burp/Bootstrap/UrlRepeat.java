package burp.Bootstrap;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class UrlRepeat {
    private Map<String, Integer> requestMethodAndUrlMap = new HashMap();

    public UrlRepeat() {
    }

    public Map<String, Integer> getRequestMethodAndUrlMap() {
        return this.requestMethodAndUrlMap;
    }

    public void addMethodAndUrl(String requestMethod, String url) {
        if (requestMethod != null && requestMethod.length() > 0) {
            if (url != null && url.length() > 0) {
                this.getRequestMethodAndUrlMap().put(requestMethod + " " + url, 1);
            } else {
                throw new IllegalArgumentException("url不能为空");
            }
        } else {
            throw new IllegalArgumentException("请求方法不能为空");
        }
    }

    public void delMethodAndUrl(String requestMethod, String url) {
        if (requestMethod != null && requestMethod.length() > 0) {
            if (url != null && url.length() > 0) {
                this.getRequestMethodAndUrlMap().remove(requestMethod + " " + url);
            }
        }
    }

    public boolean check(String requestMethod, String url) {
        return this.getRequestMethodAndUrlMap().get(requestMethod + " " + url) != null;
    }

    public String RemoveUrlParameterValue(String url) {
        try {
            String newUrl = "";
            URL url1 = new URL(url);
            String urlQuery = url1.getQuery();
            if (urlQuery == null) {
                return url;
            } else {
                String noParameterUrl = url.replace(urlQuery, "");
                newUrl = noParameterUrl + this.RemoveParameterValue(urlQuery);
                return newUrl;
            }
        } catch (MalformedURLException var6) {
            throw new RuntimeException(var6);
        }
    }

    private String RemoveParameterValue(String urlQuery) {
        String parameter = "";
        String[] var3 = urlQuery.split("&");
        int var4 = var3.length;

        for(int var5 = 0; var5 < var4; ++var5) {
            String query = var3[var5];
            String[] parameterList = query.split("=");
            parameter = parameter + parameterList[0] + "=&";
        }

        parameter = parameter.substring(0, parameter.length() - 1);
        return parameter;
    }
}
