package burp.Bootstrap;

import java.util.HashMap;
import java.util.Map;

public class DomainNameRepeat {
    private Map<String, Integer> domainNameMap = new HashMap();

    public DomainNameRepeat() {
    }

    public Map<String, Integer> getDomainNameMap() {
        return this.domainNameMap;
    }

    public void add(String domainName) {
        if (domainName != null && domainName.length() > 0) {
            this.getDomainNameMap().put(domainName, 1);
        } else {
            throw new IllegalArgumentException("域名不能为空");
        }
    }

    public void del(String domainName) {
        if (this.getDomainNameMap().get(domainName) != null) {
            this.getDomainNameMap().remove(domainName);
        }

    }

    public boolean check(String domainName) {
        return this.getDomainNameMap().get(domainName) != null;
    }
}
