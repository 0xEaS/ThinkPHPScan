package burp;

import burp.Application.TPDetection;
import burp.Bootstrap.DomainNameRepeat;
import java.io.PrintWriter;
import java.net.URL;
import java.util.List;

public class BurpExtender implements IBurpExtender, IScannerCheck{
    public static String NAME = "TPScan";
    private Tags tags;
    private PrintWriter stdout;
    private IBurpExtenderCallbacks callbacks;
    private IExtensionHelpers helpers;
    private DomainNameRepeat domainNameRepeat;

    //加载扩展时调用此方法
    @Override
    public void registerExtenderCallbacks(final IBurpExtenderCallbacks callbacks) {
        this.stdout = new PrintWriter(callbacks.getStdout(), true);
        this.callbacks = callbacks;
        this.helpers = callbacks.getHelpers();
        this.domainNameRepeat = new DomainNameRepeat();
        this.tags = new Tags(callbacks, NAME);
        callbacks.setExtensionName(NAME); //设置扩展的名字
        callbacks.registerScannerCheck(this);//注册扫描监听
        //在output中输出
        this.stdout.println("===================================");
        this.stdout.println("author:0xEaS");
        this.stdout.println("version:1.01");
        this.stdout.println("latest:2022-8-15");
        this.stdout.println("===================================");
    }


    @Override
    public List<IScanIssue> doPassiveScan(IHttpRequestResponse baseRequestResponse) {
        URL baseHttpRequestUrl = this.helpers.analyzeRequest(baseRequestResponse).getUrl();
        String baseRequestProtocol = baseRequestResponse.getHttpService().getProtocol();
        String baseRequestHost = baseRequestResponse.getHttpService().getHost();
        int baseRequestPort = baseRequestResponse.getHttpService().getPort();
        String baseRequestDomainName = baseRequestProtocol + "://" + baseRequestHost + ":" + baseRequestPort;
        try{
            String baseUrl = baseHttpRequestUrl.toString().substring(0, baseHttpRequestUrl.toString().lastIndexOf("/"));
            URL newRequestUrl = new URL(baseUrl + "/index.php");
            IHttpRequestResponse newHttpRequestResponse = callbacks.makeHttpRequest(baseRequestResponse.getHttpService(), helpers.buildHttpRequest(newRequestUrl));
            if (helpers.analyzeResponse(newHttpRequestResponse.getResponse()).getStatusCode() >= 200 && helpers.analyzeResponse(newHttpRequestResponse.getResponse()).getStatusCode() < 300){
                baseHttpRequestUrl = newRequestUrl;
                baseRequestResponse = newHttpRequestResponse;
                if (this.domainNameRepeat.check(baseRequestDomainName)) {
                    return null;
                }else {
                    try{
                        int tagId = this.tags.add(baseHttpRequestUrl.toString(), this.helpers.analyzeResponse(baseRequestResponse.getResponse()).getStatusCode() + "", "waiting for test results", baseRequestResponse);
                        TPDetection tpDetection = new TPDetection(this.stdout, this.callbacks, this.helpers, baseRequestResponse, baseUrl);
                        if(tpDetection.IsVulExists()){
                            this.domainNameRepeat.add(baseRequestDomainName);
                            IHttpRequestResponse VulRequestResponse = tpDetection.getHttpRequestResponse();
                            String vulUrl = tpDetection.GetVulUrl();
                            this.tags.save(tagId, vulUrl, this.helpers.analyzeResponse(baseRequestResponse.getResponse()).getStatusCode() + "", "[+] found Vul Exp", VulRequestResponse);
                        }else{
                            this.tags.save(tagId, baseHttpRequestUrl.toString(), this.helpers.analyzeResponse(baseRequestResponse.getResponse()).getStatusCode() + "", "[-] not found Vul", baseRequestResponse);
                        }
                    }catch (Exception e){
                        this.stdout.println(e);
                    }
                }
            }
        }catch (Exception e) {
            this.stdout.println(e);
        }
        return null;
    }

    @Override
    public List<IScanIssue> doActiveScan(IHttpRequestResponse baseRequestResponse, IScannerInsertionPoint insertionPoint) {
        return null;
    }

    @Override
    public int consolidateDuplicateIssues(IScanIssue existingIssue, IScanIssue newIssue) {
        return existingIssue.getIssueName().equals(newIssue.getIssueName()) ? -1 : 0;
    }
}
